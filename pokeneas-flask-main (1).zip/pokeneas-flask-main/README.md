# Pokeneas Flask
Proyecto del Taller 02 – AWS.  
Aplicación Flask para mostrar Pokeneas con imágenes desde Amazon S3.

Realizado por:
- Juan Camilo Ramón Perez
- Valentina Castro Pineda
